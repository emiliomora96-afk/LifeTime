import './miniBoard.css'
import type { CSSProperties } from 'react'
import type { Club } from './types'
import type { LeagueState } from './engine'
import Crest from './Crest'
import { ZONE_COLOR } from './zones'
import { buildBoard, nextMatch } from './miniBoard'
import type { BoardRow } from './miniBoard'

interface Props {
  club: Club
  league: LeagueState
  onOpenTable?: () => void
}

function Trend({ move }: { move: number }) {
  if (move > 0)
    return (
      <span className="mb-trend up" role="img" aria-label={`Sube ${move} ${move === 1 ? 'puesto' : 'puestos'}`}>
        ▲{move}
      </span>
    )
  if (move < 0)
    return (
      <span className="mb-trend down" role="img" aria-label={`Baja ${-move} ${move === -1 ? 'puesto' : 'puestos'}`}>
        ▼{-move}
      </span>
    )
  return (
    <span className="mb-trend same" role="img" aria-label="Sin cambios">
      –
    </span>
  )
}

function Row({ r, club }: { r: BoardRow; club: Club }) {
  const style = r.zone ? ({ '--zone': ZONE_COLOR[r.zone] } as CSSProperties) : undefined
  return (
    <li className={'mb-row' + (r.isMe ? ' me' : '') + (r.zone ? ' zoned' : '')} style={style} aria-current={r.isMe ? 'true' : undefined}>
      <span className="mb-pos">{r.pos}</span>
      <Trend move={r.move} />
      <span className="mb-crest">
        <Crest name={r.name} shape={r.isMe ? club.crestShape : 'classic'} primary={r.colors[0]} secondary={r.colors[1]} size={20} />
      </span>
      <span className="mb-name">{r.name}</span>
      <span className="mb-num">{r.played}</span>
      <span className={'mb-num mb-gd' + (r.gd > 0 ? ' pos' : r.gd < 0 ? ' neg' : '')}>{r.gd > 0 ? `+${r.gd}` : r.gd}</span>
      <strong className="mb-num mb-pts">{r.points}</strong>
    </li>
  )
}

// Mini pizarra táctica: tu club en el centro, 4 equipos arriba y 4 abajo.
export default function MiniBoard({ club, league, onOpenTable }: Props) {
  const board = buildBoard(league, club)
  const next = nextMatch(league)

  return (
    <section className="miniboard" aria-label={`Clasificación de la ${board.level}.ª división, cerca de tu club`}>
      <header className="mb-head">
        <h3>Pizarra · {board.level}.ª división</h3>
        {onOpenTable && (
          <button type="button" className="mb-open" onClick={onOpenTable}>
            Tabla completa
          </button>
        )}
      </header>

      <div className="mb-cols" aria-hidden="true">
        <span className="mb-c-pos">#</span>
        <span className="mb-c-name">Club</span>
        <span className="mb-num">PJ</span>
        <span className="mb-num">DG</span>
        <span className="mb-num">Pts</span>
      </div>

      <ol className="mb-list">
        {board.rows.map((r) => (
          <Row key={r.id} r={r} club={club} />
        ))}
      </ol>

      <div className="mb-next">
        <span className="mb-next-x" aria-hidden="true">✕ → ○</span>
        {next ? (
          <span className="mb-next-txt">
            <small>
              Próximo · J{next.round} · {next.home ? 'En casa' : 'De visita'}
            </small>
            <strong>
              {next.home ? 'vs' : '@'} {next.rival}
            </strong>
          </span>
        ) : (
          <span className="mb-next-txt">
            <small>Próximo partido</small>
            <strong>Temporada completada</strong>
          </span>
        )}
      </div>
    </section>
  )
}
