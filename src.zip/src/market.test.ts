import { describe, expect, it } from 'vitest'
import { createRng } from './rng'
import { advance, initialGame } from './game'
import type { GameState } from './game'
import { USER_ID, getUserSquad } from './engine'
import type { SimTeam } from './engine'
import {
  MIN_PER_POS,
  askingPrice,
  buildOffers,
  buyBlocker,
  buyPlayer,
  listMarket,
  marketOpen,
  quickBuyer,
  quickSalePrice,
  sellBlocker,
  sellPlayer,
} from './market'
import { marketValue } from './players'
import { MAX_SQUAD, SQUAD_TEMPLATE, squadStrength } from './squads'

function teamById(game: GameState, id: number): SimTeam {
  const all = [...game.league.divisions[1].teams, ...game.league.divisions[2].teams]
  return all.find((t) => t.id === id) as SimTeam
}

describe('mercado: cuándo abre', () => {
  it('abre en Verano e Invierno y cierra en el Cierre y en las paradas por evento', () => {
    expect(marketOpen({ eventId: null, baseStop: 'verano' })).toBe(true)
    expect(marketOpen({ eventId: null, baseStop: 'invierno' })).toBe(true)
    expect(marketOpen({ eventId: null, baseStop: 'cierre' })).toBe(false)
    expect(marketOpen({ eventId: 'oferta-record', baseStop: 'invierno' })).toBe(false)
  })
})

describe('mercado: fichar', () => {
  const game = initialGame(createRng(11))
  const listings = listMarket(game.league)

  it('lista a todos los jugadores de los rivales y ninguno del club del jugador', () => {
    expect(listings.length).toBeGreaterThan(700)
    expect(listings.some((l) => l.teamId === USER_ID)).toBe(false)
  })

  it('los gigantes piden más que un club normal por un jugador igual', () => {
    const giant = listings.find((l) => teamById(game, l.teamId).anchor !== undefined)
    expect(giant).toBeTruthy()
    if (giant) expect(giant.price).toBeGreaterThan(marketValue(giant.player) * 1.2)
    const normal = listings.find((l) => teamById(game, l.teamId).anchor === undefined)
    if (normal) expect(normal.price).toBe(askingPrice(normal.player, teamById(game, normal.teamId)))
  })

  it('el jugador pasa a tu plantilla y el rival repone la plaza', () => {
    const listing = listings.find((l) => l.player.pos === 'MED' && l.teamId !== USER_ID) as (typeof listings)[0]
    const before = getUserSquad(game.league).length
    const rivalBefore = teamById(game, listing.teamId).squad.length
    const next = buyPlayer(game.league, listing, game.seed)

    const mine = getUserSquad(next)
    expect(mine).toHaveLength(before + 1)
    const bought = mine.find((p) => p.id === listing.player.id)
    expect(bought).toBeTruthy()
    expect(bought?.starter === true || bought?.starter === false).toBe(true)

    const rival = [...next.divisions[1].teams, ...next.divisions[2].teams].find(
      (t) => t.id === listing.teamId,
    ) as SimTeam
    expect(rival.squad.some((p) => p.id === listing.player.id)).toBe(false)
    expect(rival.squad.length).toBeGreaterThanOrEqual(rivalBefore - 1)
    expect(rival.squad.filter((p) => p.pos === 'MED').length).toBeGreaterThanOrEqual(SQUAD_TEMPLATE.MED)
    expect(rival.strength).toBe(squadStrength(rival.squad))
    expect(rival.squad.filter((p) => p.starter)).toHaveLength(11)
  })

  it('no se puede fichar con el mercado cerrado, sin dinero o con la plantilla llena', () => {
    const l = listings[0]
    expect(buyBlocker(game, l.price, l)).toBeNull()
    expect(buyBlocker(game, l.price - 1, l)).toMatch(/presupuesto/)
    expect(buyBlocker({ ...game, baseStop: 'cierre' }, 1e9, l)).toMatch(/cerrado/)

    let full = game.league
    for (let i = getUserSquad(full).length; i < MAX_SQUAD; i++) {
      const extra = { ...listings[i + 5].player, id: 'extra' + i }
      full = buyPlayer(full, { ...listings[i + 5], player: extra }, 1)
    }
    expect(buyBlocker({ ...game, league: full }, 1e9, l)).toMatch(/llena/)
  })
})

describe('mercado: vender', () => {
  const game = initialGame(createRng(12))
  const squad = getUserSquad(game.league)

  it('un jugador vendido sale de tu plantilla y llega a otro club sin pasarse de 24', () => {
    const player = squad.find((p) => p.pos === 'DEF' && !p.starter) ?? squad[0]
    const buyer = quickBuyer(game, player.id)
    const next = sellPlayer(game.league, player.id, buyer.id)
    expect(getUserSquad(next).some((p) => p.id === player.id)).toBe(false)
    const team = [...next.divisions[1].teams, ...next.divisions[2].teams].find((t) => t.id === buyer.id) as SimTeam
    expect(team.squad.some((p) => p.id === player.id)).toBe(true)
    expect(team.squad.length).toBeLessThanOrEqual(MAX_SQUAD)
    expect(team.squad.filter((p) => p.starter)).toHaveLength(11)
  })

  it('la venta directa paga menos que el valor de mercado', () => {
    for (const p of squad) expect(quickSalePrice(p)).toBeLessThan(marketValue(p))
  })

  it('no se puede vender si te quedas sin los jugadores mínimos de la posición', () => {
    // la plantilla de arranque tiene 2 porteros: el mínimo es 2, así que ninguno se puede vender
    const keepers = squad.filter((p) => p.pos === 'POR')
    expect(keepers.length).toBe(MIN_PER_POS.POR)
    expect(sellBlocker(game, keepers[0])).toMatch(/al menos/)
    expect(
      sellBlocker({ ...game, baseStop: 'cierre' }, squad.find((p) => p.pos === 'DEL') as (typeof squad)[0]),
    ).toMatch(/cerrado/)
  })
})

describe('mercado: ofertas', () => {
  it('hay como mucho 3 ofertas, por jugadores tuyos y por al menos el 95% de su valor', () => {
    const game = initialGame(createRng(13))
    const squad = getUserSquad(game.league)
    for (let seed = 1; seed <= 20; seed++) {
      const offers = buildOffers(game, createRng(seed))
      expect(offers.length).toBeLessThanOrEqual(3)
      for (const o of offers) {
        const p = squad.find((s) => s.id === o.playerId)
        expect(p).toBeTruthy()
        if (p) expect(o.amount).toBeGreaterThanOrEqual(marketValue(p) * 0.94)
        expect(o.teamId).not.toBe(USER_ID)
      }
    }
  })

  it('no hay ofertas con el mercado cerrado', () => {
    const game = initialGame(createRng(14))
    expect(buildOffers({ ...game, baseStop: 'cierre' }, createRng(1))).toEqual([])
  })

  it('al avanzar a una parada sin mercado las ofertas desaparecen', () => {
    let game = initialGame(createRng(15))
    const rng = createRng(16)
    for (let i = 0; i < 12; i++) {
      game = advance(game, rng)
      if (!marketOpen(game)) expect(game.offers).toEqual([])
    }
  }, 60000)
})
