// Dibujo del campo estilo anime (SVG). Solo es decoración de fondo.
export const PITCH_SVG = `<svg viewBox="0 0 400 500" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg" role="presentation">
<defs>
<linearGradient id="pa-shade" x1="0" y1="0" x2="0" y2="1">
<stop offset="0" stop-color="#fffbd0" stop-opacity=".22"/><stop offset=".45" stop-color="#fff" stop-opacity="0"/><stop offset="1" stop-color="#012a14" stop-opacity=".38"/>
</linearGradient>
<radialGradient id="pa-lamp" cx=".5" cy=".5" r=".5">
<stop offset="0" stop-color="#fff7c2" stop-opacity=".34"/><stop offset=".5" stop-color="#fff7c2" stop-opacity=".1"/><stop offset="1" stop-color="#fff7c2" stop-opacity="0"/>
</radialGradient>
<pattern id="pa-tone" width="7" height="7" patternUnits="userSpaceOnUse" patternTransform="rotate(30)">
<circle cx="3.5" cy="3.5" r="1.05" fill="#00361a"/>
</pattern>
<linearGradient id="pa-fadeb" x1="0" y1="1" x2="0" y2="0">
<stop offset="0" stop-color="#fff"/><stop offset="1" stop-color="#000"/>
</linearGradient>
<mask id="pa-mb"><rect y="330" width="400" height="170" fill="url(#pa-fadeb)"/></mask>
<radialGradient id="pa-vig" cx=".5" cy=".5" r=".75">
<stop offset=".55" stop-color="#001a0c" stop-opacity="0"/><stop offset="1" stop-color="#001a0c" stop-opacity=".6"/>
</radialGradient>
<radialGradient id="pa-centerglow" cx=".5" cy=".5" r=".5">
<stop offset="0" stop-color="#d9ffe6" stop-opacity=".22"/><stop offset="1" stop-color="#d9ffe6" stop-opacity="0"/>
</radialGradient>
<pattern id="pa-blades" width="18" height="18" patternUnits="userSpaceOnUse">
<path d="M2 12 L3.2 6.5 M9 7 L10.2 2 M6 13.5 L7.4 10" stroke="#a7f3b8" stroke-width="1.1" stroke-linecap="round" opacity=".2"/>
<path d="M11.5 13 L12.3 10.5" stroke="#0f5f2c" stroke-width="1" stroke-linecap="round" opacity=".18"/>
</pattern>
<pattern id="pa-net" width="4" height="4" patternUnits="userSpaceOnUse">
<path d="M0 0 L4 4 M4 0 L0 4" stroke="#fff" stroke-width=".6" opacity=".75"/>
</pattern>
<filter id="pa-glow" x="-5%" y="-5%" width="110%" height="110%"><feGaussianBlur stdDeviation="2.4"/></filter>
<filter id="pa-soft"><feGaussianBlur stdDeviation="3.2"/></filter>
<g id="pa-lines" fill="none" stroke-linecap="round" stroke-linejoin="round">
<rect x="14" y="14" width="372" height="472" rx="6"/>
<path d="M14 250 H386"/>
<circle cx="200" cy="250" r="46"/>
<rect x="100" y="14" width="200" height="70"/>
<rect x="150" y="14" width="100" height="26"/>
<path d="M173.2 84 A36 36 0 0 0 226.8 84"/>
<rect x="100" y="416" width="200" height="70"/>
<rect x="150" y="460" width="100" height="26"/>
<path d="M173.2 416 A36 36 0 0 1 226.8 416"/>
<path d="M14 24 A10 10 0 0 0 24 14 M376 14 A10 10 0 0 0 386 24 M14 476 A10 10 0 0 1 24 486 M376 486 A10 10 0 0 1 386 476"/>
</g>
</defs>
<rect x="0" y="0.0" width="400" height="62.5" fill="#27b052"/><rect x="0" y="62.5" width="400" height="62.5" fill="#198236"/><rect x="0" y="125.0" width="400" height="62.5" fill="#27b052"/><rect x="0" y="187.5" width="400" height="62.5" fill="#198236"/><rect x="0" y="250.0" width="400" height="62.5" fill="#27b052"/><rect x="0" y="312.5" width="400" height="62.5" fill="#198236"/><rect x="0" y="375.0" width="400" height="62.5" fill="#27b052"/><rect x="0" y="437.5" width="400" height="62.5" fill="#198236"/>
<rect width="400" height="500" fill="url(#pa-blades)"/>
<circle cx="10" cy="0" r="260" fill="url(#pa-lamp)"/>
<circle cx="390" cy="0" r="260" fill="url(#pa-lamp)"/>
<circle cx="200" cy="250" r="120" fill="url(#pa-centerglow)"/>
<rect width="400" height="500" fill="url(#pa-shade)"/>
<rect width="400" height="500" fill="url(#pa-tone)" mask="url(#pa-mb)" opacity=".5"/>
<g filter="url(#pa-soft)"><circle cx="34" cy="8" r="9" fill="#fde68a" opacity="0.35"/><circle cx="92" cy="22" r="6" fill="#a5f3fc" opacity="0.3"/><circle cx="150" cy="6" r="8" fill="#fef3c7" opacity="0.3"/><circle cx="238" cy="18" r="7" fill="#fde68a" opacity="0.3"/><circle cx="300" cy="5" r="10" fill="#a5f3fc" opacity="0.28"/><circle cx="362" cy="20" r="8" fill="#fde68a" opacity="0.35"/><circle cx="60" cy="488" r="8" fill="#a5f3fc" opacity="0.25"/><circle cx="180" cy="494" r="7" fill="#fde68a" opacity="0.25"/><circle cx="270" cy="490" r="9" fill="#fef3c7" opacity="0.25"/><circle cx="345" cy="486" r="7" fill="#a5f3fc" opacity="0.25"/></g>
<use href="#pa-lines" stroke="#ffffff" stroke-width="5" opacity=".32" filter="url(#pa-glow)"/>
<use href="#pa-lines" stroke="#f0fff4" stroke-width="2.2" opacity=".92"/>
<circle cx="200" cy="250" r="3.2" fill="#f0fff4"/><circle cx="200" cy="60" r="2.4" fill="#f0fff4"/><circle cx="200" cy="440" r="2.4" fill="#f0fff4"/>
<circle cx="200" cy="250" r="40" fill="#fff" opacity=".035"/>
<rect x="168" y="2" width="64" height="12" rx="2" fill="url(#pa-net)" stroke="#fff" stroke-width="2" opacity=".95"/>
<rect x="168" y="486" width="64" height="12" rx="2" fill="url(#pa-net)" stroke="#fff" stroke-width="2" opacity=".95"/>
<g stroke="#fff" stroke-width="1.4"><path d="M17 17 V4" /><path d="M383 17 V4" /><path d="M17 483 V496" /><path d="M383 483 V496" /></g>
<g fill="#ff4d6d"><path d="M17 4 L28 8 L17 12Z"/><path d="M383 4 L372 8 L383 12Z"/><path d="M17 496 L28 492 L17 488Z"/><path d="M383 496 L372 492 L383 488Z"/></g>
<g transform="translate(62 138) scale(1.0)"><path class="tw" style="animation-delay:0s" d="M0 -8 L1.8 -1.8 L8 0 L1.8 1.8 L0 8 L-1.8 1.8 L-8 0 L-1.8 -1.8Z" fill="#ffffff"/></g><g transform="translate(338 104) scale(1.3)"><path class="tw" style="animation-delay:0.8s" d="M0 -8 L1.8 -1.8 L8 0 L1.8 1.8 L0 8 L-1.8 1.8 L-8 0 L-1.8 -1.8Z" fill="#ffffff"/></g><g transform="translate(112 318) scale(0.8)"><path class="tw" style="animation-delay:1.5s" d="M0 -8 L1.8 -1.8 L8 0 L1.8 1.8 L0 8 L-1.8 1.8 L-8 0 L-1.8 -1.8Z" fill="#ffffff"/></g><g transform="translate(296 372) scale(1.1)"><path class="tw" style="animation-delay:2.1s" d="M0 -8 L1.8 -1.8 L8 0 L1.8 1.8 L0 8 L-1.8 1.8 L-8 0 L-1.8 -1.8Z" fill="#ffffff"/></g><g transform="translate(52 436) scale(0.9)"><path class="tw" style="animation-delay:0.4s" d="M0 -8 L1.8 -1.8 L8 0 L1.8 1.8 L0 8 L-1.8 1.8 L-8 0 L-1.8 -1.8Z" fill="#ffffff"/></g><g transform="translate(348 452) scale(1.0)"><path class="tw" style="animation-delay:1.2s" d="M0 -8 L1.8 -1.8 L8 0 L1.8 1.8 L0 8 L-1.8 1.8 L-8 0 L-1.8 -1.8Z" fill="#ffffff"/></g><g transform="translate(206 176) scale(0.7)"><path class="tw" style="animation-delay:1.9s" d="M0 -8 L1.8 -1.8 L8 0 L1.8 1.8 L0 8 L-1.8 1.8 L-8 0 L-1.8 -1.8Z" fill="#ffffff"/></g>
<rect width="400" height="500" fill="url(#pa-vig)"/>
</svg>`
