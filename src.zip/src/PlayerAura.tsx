import type { ReactNode } from 'react'
import './aura.css'
import { auraOf, crossedTier } from './aura'

interface Props {
  rating: number
  lastGain?: number
  /** 'round' = círculo (campo). 'card' = cuadrado redondeado (ficha). */
  shape?: 'round' | 'card'
  /** Tamaño en px. Si se omite, ocupa el 100% de su contenedor. */
  size?: number
  children: ReactNode
}

// Marco con aura animada alrededor de cualquier contenido (el retrato del jugador).
export default function PlayerAura({ rating, lastGain, shape = 'round', size, children }: Props) {
  const { tier, color } = auraOf(rating)
  const levelUp = crossedTier(rating, lastGain)
  return (
    <div
      className={`aura aura-${tier} aura-${shape}${levelUp ? ' aura-levelup' : ''}`}
      style={{ ['--aura-c' as string]: color, ...(size ? { width: size, height: size } : null) }}
    >
      <span className="aura-glow" aria-hidden="true" />
      <span className="aura-ring" aria-hidden="true" />
      <span className="aura-ring aura-ring-2" aria-hidden="true" />
      <div className="aura-face">{children}</div>
    </div>
  )
}
