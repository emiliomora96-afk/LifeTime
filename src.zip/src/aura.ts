// Nivel de aura según la valoración del jugador.
// Para cambiar los cortes (70/80/90/95) o los nombres, solo toca esta tabla.
export type AuraTier = 'none' | 'bronze' | 'gold' | 'fire' | 'storm'

export const AURA_TIERS: { tier: AuraTier; min: number; label: string; color: string }[] = [
  { tier: 'storm', min: 95, label: 'Rayo', color: '#38bdf8' },
  { tier: 'fire', min: 90, label: 'Fuego', color: '#ff5a1f' },
  { tier: 'gold', min: 80, label: 'Oro', color: '#fbbf24' },
  { tier: 'bronze', min: 70, label: 'Bronce', color: '#c8843c' },
]

const NONE = { tier: 'none' as AuraTier, min: 0, label: '', color: '#94a3b8' }

export function auraOf(rating: number) {
  return AURA_TIERS.find((t) => rating >= t.min) ?? NONE
}

export function auraTier(rating: number): AuraTier {
  return auraOf(rating).tier
}

// true si en la última temporada el jugador cruzó un umbral (ej. de 79 a 80)
export function crossedTier(rating: number, lastGain: number | undefined): boolean {
  if (!lastGain || lastGain <= 0) return false
  return auraTier(rating) !== auraTier(rating - lastGain)
}
