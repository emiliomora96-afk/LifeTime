import { describe, expect, it } from 'vitest'
import { createRng } from './rng'
import { ACADEMY_CAPACITY, ACADEMY_MAX_AGE, ageAcademy, generateIntake, intakeSize } from './academy'
import { advance, initialGame } from './game'
import { getUserSquad } from './engine'

describe('cantera', () => {
  it('las plazas dependen del nivel de inversión', () => {
    expect(ACADEMY_CAPACITY).toEqual([4, 6, 8, 10])
    expect(ACADEMY_CAPACITY[3]).toBeGreaterThan(ACADEMY_CAPACITY[0])
  })

  it('llegan 2 + nivel juveniles por temporada, sin pasar de las plazas libres', () => {
    expect(intakeSize(0, 0)).toBe(2)
    expect(intakeSize(3, 0)).toBe(5)
    expect(intakeSize(1, 5)).toBe(1) // 6 plazas, 5 ocupadas
    expect(intakeSize(1, 6)).toBe(0)
    expect(intakeSize(1, 9)).toBe(0)
  })

  it('los juveniles nuevos tienen 16 a 18 años, nacionalidad y nombre', () => {
    const youths = generateIntake([], 3, 70, 1, createRng(4))
    expect(youths).toHaveLength(5)
    for (const y of youths) {
      expect(y.age).toBeGreaterThanOrEqual(16)
      expect(y.age).toBeLessThanOrEqual(18)
      expect(y.nat).toBeTruthy()
      expect(y.first && y.last).toBeTruthy()
    }
    expect(new Set(youths.map((y) => y.id)).size).toBe(youths.length)
  })

  it('más inversión da juveniles con más potencial', () => {
    function avgPeak(level: number): number {
      const rng = createRng(9)
      let sum = 0
      let n = 0
      for (let i = 0; i < 300; i++) {
        for (const y of generateIntake([], level, 70, i, rng)) {
          sum += y.peak
          n++
        }
      }
      return sum / n
    }
    expect(avgPeak(3)).toBeGreaterThan(avgPeak(0) + 3)
  })

  it('al pasar un año crecen y los que pasan de 19 se van', () => {
    const rng = createRng(2)
    const youths = generateIntake([], 3, 70, 1, rng).map((y, i) => ({ ...y, age: 16 + (i % 4), id: 'x' + i }))
    const aged = ageAcademy(youths, rng)
    expect(aged.every((p) => p.age <= ACADEMY_MAX_AGE)).toBe(true)
    const survivors = youths.filter((y) => y.age + 1 <= ACADEMY_MAX_AGE).length
    expect(aged).toHaveLength(survivors)
    for (const p of aged) {
      const before = youths.find((y) => y.id === p.id)
      expect(p.rating).toBeGreaterThanOrEqual(before?.rating ?? 0)
      expect(p.starts).toBe(0)
    }
  })

  it('la partida empieza con la cantera llena según su inversión', () => {
    const game = initialGame(createRng(3))
    expect(game.academy).toHaveLength(intakeSize(game.investments.academy, 0))
  })

  it('durante 10 temporadas la cantera respeta las plazas y la edad, sin ids repetidos', () => {
    let game = initialGame(createRng(5))
    const rng = createRng(6)
    let guard = 0
    while (game.season < 11 && guard++ < 200) {
      game = advance(game, rng)
      expect(game.academy.length).toBeLessThanOrEqual(ACADEMY_CAPACITY[game.investments.academy])
      expect(game.academy.every((p) => p.age <= ACADEMY_MAX_AGE)).toBe(true)
      const ids = [...game.academy.map((p) => p.id), ...getUserSquad(game.league).map((p) => p.id)]
      expect(new Set(ids).size).toBe(ids.length)
    }
    expect(game.season).toBe(11)
    expect(game.academy.length).toBeGreaterThan(0)
  }, 60000)
})
